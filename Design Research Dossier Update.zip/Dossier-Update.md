# Dossier update — design session, round 1

**How to use this.** Everything below is keyed to the existing section numbers of
`Design-Research-Dossier.md` and is meant to be merged into it (I can read the linked repo
but not write to it). Two kinds of content: **answers** that close the dossier's open
questions, and **§6**, a new section the dossier is missing entirely — the field taxonomy,
which `YandexDeliveryExpressDemo` makes visible and the research half did not account for.

Artefacts this refers to, all in the design project:

| File | What it holds |
|---|---|
| `YDelivery — Shipped Today.dc.html` | Baseline: ten frames recreated from the shipped `#Preview`s |
| `Round 1 - Route & Ordering.dc.html` | `1a` map-first shell, `1b` fixed-card shell |
| `Round 1 - Picker & Points.dc.html` | `2a` picker (8 states), `2b` multi-point ladder, `2c` pin/badge spec |
| `Round 1 - Tariffs, Fields & XL.dc.html` | `3a`/`3b`/`3c` beginner explainer, `3d` parcel & options, `3e` saved place & history, `3f` accessibility-XL |
| `Round 2 - Callouts, Custom Fields & Motion.dc.html` | `4a` map callouts, `4b` custom fields, `4c` motion spec |
| `Round 3 - System Surfaces.dc.html` | `5a` Live Activity & Dynamic Island, `5b` widgets, `5c` notifications, `5d` intents/Spotlight/sharing, `5e` shared components, `5f` HIG audit |
| `Positioning.md` | Purpose, audience, promotional prose |

---

## Answers to §1.5 — the destination interface

**Q1 — where does the tariff strip live?** Both, and the split is not a compromise: the
strip's *position* and the *moment price arrives* are separate decisions, and the dossier
conflated them. Draw the strip on the route card (2GIS position, `1b`) and let it hold a
waiting state; the Uber position (`1a`) is the same strip further down a sheet that grows.
The recommendation is **`1b`, the fixed card** — for a reason the dossier could not have
known before the demo was read: filled point rows are two lines (address + contact), route
lists reach 5 and 10 points, and a bottom sheet that must be dragged to read the route is
the wrong shell for that. `1a` remains the better shell if the app ever becomes
courier-hailing rather than parcel-sending.

**Q2 — beginner cards, paged or vertical?** Vertical list (`3a`). `3f` is the argument: at
`accessibility-extra-large` the horizontal strip cannot survive and becomes a vertical list
anyway, so a paged-card explainer (`3b`) would need a second layout to fall back to. `3c`,
expand-in-strip, is worth keeping as the *expert* affordance — it answers "what am I
paying for" without a second surface — but it is not the beginner mode. Proposed rule,
unchanged from the dossier apart from being specific: the sheet auto-opens until the first
successful order, then lives behind the ⓘ, and `3c` handles the in-place case forever after.

**Q3 — where do contacts enter?** On the draft screen, as a collapsed row under each point
(`1a`, `1b`, `2b`). Empty renders as an action ("Кто отдаёт — имя и телефон"), filled
renders as a value line with Изменить. The picker stays a picker. One addition the demo
forces: a saved place *carries* its contact (`3e`), so choosing «Склад на Невском» fills the
contact row too, and the common case has no contact step at all.

## Answers to §2.3 — pins and lists

**Q1 — do warehouse/ПВЗ/locker markers show on the picker map?** Only when the suggestion
list surfaces them, plus saved places always. A map of every locker in Moscow is noise in an
app whose job is sending, not finding.

**Q2 — flag or pin for the end?** Pin (`mappin.circle.fill`), per `2c`. A checkered flag
reads as "finish line" — right for navigation, wrong for a place where a human takes a
parcel from a courier.

**Q3 — numbered circles at accessibility sizes.** `3f` ladder: the number keeps its size and
the row grows; address and contact stack; three lines are permitted before truncation.
Truncating an address is never acceptable — a wrong address is a failed delivery.

## Answers to §3.4 — links and coordinates

**Q1 — row or banner?** Row atop suggestions, with a mini-map preview of the resolved point
(`2a`, frame 4). Declined offers do not reappear for the same URL in the same session; the
row is a paste **button**, never an ambient pasteboard scan.

**Q2 — route links with two ends?** One action, "заполнить обе точки", with the two
resolved addresses listed inside the row so the user sees what will be filled. Two separate
suggestions would let someone fill the destination from a route link and silently keep a
stale origin.

**Q3 — recents: timestamp or not?** Not by default. `2a` shows the second line spent on
something more useful: the saved contact, when there is one. Relative time appears only when
it disambiguates two recents with the same title ("был вчера").

## Answers to §4 — route preview

**Q1 — is the info bar the CTA?** No. Keep them apart: the estimate is information, the CTA
is commitment, and merging them makes a failed estimate look like a broken order button.

**Q2 — on estimate failure, does the CTA move?** No. The bar keeps its height and renders
the failure plus Повторить (`1b`, frame 3). Pricing is unaffected; the bar failing must
never look like the order failing.

**Q3 — keep the MKDirections time once real offers arrive?** Replace it. Two times on one
screen, one from Apple and one from the provider, is a bug report waiting to be filed.

## Answers to §5 — permissions

**Q1 — `LocationButton`?** Use the custom row plus the standard flow (`2a`, frame 7). The
picker's "Моё местоположение" row must sit in a list with "Выбрать на карте" and the saved
chips; a system-drawn button cannot match that row's metrics at accessibility sizes.

**Q2 — does reduced accuracy get its own copy?** Yes, one line, because the failure is
silent otherwise: the pin lands plausibly but a kilometre out (`2a`, frame 8).

**Q3 — where does the start city live?** Settings, plus a one-time inline prompt on first
map open for the never-granted cohort.

---

## §6 (new) — What an order actually carries

The dossier treats a point as an address plus a contact. `YandexDeliveryExpressDemo` shows
that is roughly a third of it. This section exists so the visual design is sized for the
real field set rather than discovering it during implementation.

### 6.1 The fields, by group

| Group | Fields | Constraint the UI must carry |
|---|---|---|
| Address | `fullname`, `country`, `city`, `street`, `building`, `porch`, `sfloor`, `sflat`, `doorCode`, `comment`, `coordinates` | `coordinates` is **lon,lat** on the wire; everything else free text. Порч/этаж/квартира are what makes a delivery succeed and are invisible on a map |
| Contact (per point) | `name`, `phone`, `email`, `phoneAdditionalCode` | Phone formats and needs a national mask; extension is a separate field, not part of the number |
| Point | `pointId`, `visitOrder`, `_type` (`source` / `destination` / `return`), `externalOrderId`, `skipConfirmation` | Type is a first-class role — the return point in `2b` is not decoration |
| Item | `title`, `quantity`, `weight`, `costValue`, `costCurrency`, `extraId`, `size{length,width,height}`, `pickupPoint`, `dropoffPoint` | Cost is a decimal **string** with currency; size is in **metres** on the wire and must be centimetres in the UI; each item maps to a pickup and a dropoff point, so items depend on the route existing |
| Requirements | `taxiClass`, `cargoOptions[]`, `cargoType` (`van`/`lcv_m`/`lcv_l`), `cargoLoaders`, `proCourier`, `skipDoorToDoor`, `due` | Interdependent: loaders 0–2 **and only with `cargo`** (the live API answers `409 estimating.too_many_loaders`), `cargoType` only with `cargo`, thermobag only with `courier`, `due` inside a window (the demo uses +1 h … +30 d) |
| Order | `comment`, `shippingDocument` | Free text |

### 6.2 The design consequence

Three rules, drawn in `3d`:

1. **One summary line per group, expanding to typed rows.** The draft screen must stay
   readable in three seconds; the density lives one tap down. This is the difference between
   the demo (every field visible, which is right for a demo) and the app (every field
   *reachable*).
2. **Constraints replace hints.** Where a field is bounded, the bound is the helper text —
   «Грузчиков можно позвать только в „Грузовой" — там от 1 до 2», «От часа вперёд и до
   30 дней». An unavailable option renders disabled with its reason rather than vanishing,
   so the vocabulary stays learnable.
3. **Units belong to the field, never to the user.** Centimetres and kilograms in the UI,
   metres on the wire; currency is a picker; the phone extension is its own field. No
   free-text number ever means two things.

### 6.3 Saved places and history carry data, not coordinates

Your note, and it changes the IA. A saved place (`3e`) stores the whole point: address
parts, default contact, default role in the route, default options. History (`3e`, second
frame) stores the whole order, so «Повторить» refills route, contacts, items and options in
one tap, and «Наоборот» is the swapped variant. Both are local, per `Vision.md`.

Two consequences worth stating out loud before implementation:

- The picker's job shrinks. For habitual senders the common path is chip → done, with no
  typing and no contact step, which is the strongest argument for putting saved chips above
  the suggestion list rather than inside it.
- `Vision.md`'s history phase and this are the same feature. Recents, saved places and
  repeat-order all read one local store of completed points and orders; designing them as
  three surfaces would triple the work and split the truth.

---

## Proposed changes to the dossier's own structure

You invited these. Four, in order of confidence:

1. **Add §6 above** — the dossier's biggest gap is that it researched the *destination*
   interface thoroughly and the *order* barely, so the field set never got sized.
2. **§3.2's grammar table should not live in this document.** It is parser specification,
   not design research: it will outlive the design session, it belongs next to the code that
   honours it, and the dossier is marked transient and meant for deletion. Suggest moving it
   to the package repo as `LinkGrammars.md`, leaving a one-paragraph summary plus the design
   consequence (always human-verify the resolved point) behind.
3. **Split §2.2's table into a token spec.** Same reasoning: `2c` is the version the asset
   catalog is built from, and it should land in `Design.md` rather than evaporating with the
   dossier.
4. **The checklist should carry state.** It is written as unchecked boxes with no owner;
   after this round most of the destination-flow items have a drawn answer and a frame id.
   Suggest a third column — frame reference — so the checklist becomes the handoff index.

---

## Open questions back to you

1. `1b` (fixed card) is my recommendation over `1a`. Does the map deserve a third of the
   screen at all on a screen whose job is filling a form, or should the map appear only in
   the picker and the estimate be text on the draft screen?
2. The return point (`_type: return`) is drawn as a role in `2b`. Is returning the undelivered
   remainder a real flow for your senders, or an API capability that need not surface in v1?
3. Items map to pickup/dropoff points individually. `3d` hides that behind two rows because
   the common case is "everything from A to B" — is that right, or do your multi-point users
   genuinely split items across stops?
4. Currency: the demo offers a picker. Is anything other than ₽ real here, or should it be a
   fixed label until proven otherwise?

---

# Round 2–3 additions

## §7 (new) — What the app is for

See `Positioning.md` for the full prose. The load-bearing conclusion, because it should
settle arguments later: **the unit of work is the order, not the parcel.** The API is
written for shops with integration teams; the people who can actually use it are usually one
person with a phone. Three claims the app can keep — the full tariff range rather than the
consumer subset, orders that outlive the vendor's short history window, and the sender's own
identifiers on every order.

This has a direct design consequence, which is why it belongs in the dossier and not only in
a marketing file: **the sender's order number outranks the vendor's claim id on every
surface** — Live Activity, widget, notification title, Spotlight. It is the string they are
matching against a customer chat.

## §2.3 Q2 — revised: no letters

A and B are withdrawn. They were map-app shorthand carried over without a reason: they mean
nothing, they collide with numbered intermediates, and they need localizing thought at
accessibility sizes. Start is a concentric ring (`smallcircle.filled.circle`), end keeps the
teardrop (`mappin.circle.fill`). Where a row must state the action rather than the position,
`shippingbox.fill` / `house.fill`. Shape and glyph still carry the role; colour only
reinforces. Verify every symbol name in the SF Symbols app against the iOS 17 floor.

## §8 (new) — The map as a second surface

MapKit's rich annotations resolve a tension §1.4 left open. Division of labour:

- The **row** answers *is this the right place* — address, contact, two lines, forever.
- The **callout** answers *what happens when the courier arrives* — entrance, floor, flat,
  door code, comment, contact with a call button, what is going to this stop, and in a live
  order a per-stop timeline with times.

This is what lets the fixed-card shell (`1b`) survive filled rows and long routes without
growing to three lines. The standard callout is too cramped for four chips and a timeline, so
it is an `Annotation` with a custom card. Two rules: tapping a pin highlights the
corresponding row, and a callout is **never the only route to anything** — VoiceOver reaches
the same content through the row's disclosure.

Courier information does **not** go in a compressed row. One courier per order means there is
room for a proper card: name, vehicle with plate, call and message, and the arrival line.

## §9 (new) — Custom fields

Which identifiers matter differs between organizations and is identical inside one, so the
schema is a **setting**, not a per-order chore. Define «Заказ», «Платёж», «Накладная» once;
every draft shows them pre-typed and validated; history is searchable by their values with
the match highlighted in the field where it was found.

Two flags per field:

- `isOptional` — whether the order can leave without it. A required field blocks ordering and
  says so beside the field, never in an alert.
- `isShownByDefault` — whether it sits in the section from the start or waits behind
  «Добавить поле». This is what stops a ten-field schema becoming a ten-row wall for the
  eight orders in ten that need three of them.

Required implies shown: the pair cannot express «обязательное, но скрытое», and the editor
should say so rather than allow it. **«Ваши поля» is a section of its own**, not rows mixed
into the order form.

Three fields can ride along to the carrier (`extraId`, `externalOrderId`,
`shippingDocument`) and become findable in their support; the rest stay local. The UI says
which, once, quietly. Field type drives keyboard and validation — text, number, sum, date,
choice, link.

## §10 (new) — Motion

One rule: **animation reports a state change the user did not cause, or confirms one they
did — never decorates a static screen.** The full table is `4c`. Summary: variable-colour
for the indeterminate «ищем курьера» wait; `.replace` content transition on status change;
`.numericText()` for price landing; `.bounce` on point confirmed and order created;
interpolated coordinate for the courier marker; shake only where the error sits beside the
input. Every row has a Reduce Motion branch, and no celebration effects — the event being
marked is that money moved.

**On Pow:** two effects are worth taking (`.shake`, a price-change effect), both about twenty
lines to write. Recommendation is to skip the dependency and keep the vocabulary in the app
where the Reduce Motion branch is visible in the same file.

**On the deployment target:** everything above exists at **iOS 17**; motion alone does not
justify raising the floor. iOS 18 would add `breathe` — the honest "waiting, nothing is
wrong" idiom — and MapKit's place-detail presentation. Hold at 17 until something structural
wants more.

## §11 (new) — The app is mostly used while closed

Ordering takes ninety seconds; waiting takes forty minutes, and those forty minutes are spent
on the Lock Screen. This section is the one the destination research implied and never drew.
Detail in `5a`–`5d`.

**Live Activity.** A delivery has a definite start, a definite end and a monotonic status —
exactly the shape the surface is for. Content priority: where is it now, when will it be
there, who to call. Seven states, two of them final and only one of which auto-dismisses:
failures stay until tapped, because they are what the sender must act on. No live map — a
dashed remainder plus an ETA carries the same information for none of the battery. Note the
constraint: **push-to-start and ActivityKit updates need a server the app does not have**, so
the activity starts locally on order creation and updates when the app polls. Show «в 9:41»
rather than a ticking timer, to avoid implying precision that isn't there.

**Widgets.** Two jobs. *Waiting* — the active delivery, so the Home Screen answers "where is
it". *Working* — repeat a saved route, opening a pre-filled draft. A widget tap must never
move money, and the empty state offers «Повторить» rather than "no orders".

**Notifications.** While an activity is on screen, routine progress needs no push. Push only
for: courier assigned, courier at the door, delivered, and the two failures. Order number in
every title. Group by order via `threadIdentifier` so five events don't become five banners;
failed delivery is `.timeSensitive`, delivered is not. The expanded view is a content
extension with a route snapshot and actions — call, return to me — so the sender need not
open the app.

**Ways in.** The Share Sheet answers §3.4 better than any paste affordance: senders receive
addresses in chats, so sharing a place or an address into the app opens a draft with that
point filled. Three App Intents, not thirty: «где моя доставка», «повторить доставку в …»,
«отправить по заказу …». Spotlight indexes completed orders by custom-field value, so typing
«4417» finds the delivery — the payoff of §9 that lives entirely outside the app.

**Sharing outward.** The recipient wants to know where their parcel is, and today that is
manual retyping. Share plain text, not an app link — the recipient installs nothing.

## §12 (new) — The shared component set

Widgets and Live Activities cannot import the app target, so anything shared lives in a local
package below both. Membership test: *does it render from plain values with no controller, no
network, no environment?* Five pass, and they are the five that appear on every surface:
`StatusChip`, `RouteLine`, `PointBadge`, `ETALabel`, `OrderIdentity`.

Three consequences worth deciding before implementation, not after:

1. Each takes a `size` of compact / regular / expanded rather than reading Dynamic Type
   directly — a widget cannot grow, so it must shrink content instead.
2. The asset catalog moves into the same package, or the widget's green drifts from the
   app's. Widgets render on unpredictable backgrounds: every token needs light and dark, and
   none may depend on the app's material.
3. **The order store belongs in an App Group from day one.** Widgets read it directly, and
   retrofitting this after the Keychain and history exist is the expensive version of the
   decision.

## §13 (new) — HIG audit

Six findings, ordered by cost to fix later. Full text in `5f`. The two structural ones:

1. **The tab bar is wrong.** «New Delivery» is an action, and tabs are for peer locations,
   not verbs — it also means a tab switch destroys the draft. Proposal: two tabs (Доставки,
   Настройки) with a prominent «Новая доставка» on the list, presenting the flow modally. It
   follows the compose idiom and makes the draft's lifetime legible.
2. **Ordering is irreversible and nothing acknowledges it.** Money moves and a courier is
   dispatched. It needs a review sheet restating route, price and tariff — which is also the
   natural home for the required-custom-field check from §9.

Then: contact fields must declare `textContentType` and offer the Contacts picker, since a
sender is always copying details from somewhere; offline is a normal condition rather than an
error, so history and saved places must be fully readable without network and a draft must
survive being written in a basement; the map needs a VoiceOver *equivalent* rather than a
label; and the small standard wins — swipe actions on history rows, context menu on a saved
place, `.searchable` on Доставки, and the regular-width layout where the fixed card becomes
map-left / card-right.

## Open questions from rounds 2–3

1. **Does the API's journal feed actually carry courier coordinates?** The moving marker in
   `4a` and the route progress in `5a` both assume it does. If it only carries status
   transitions, both become status-only and the design still works — but I should know before
   drawing more of it.
2. **Is the tab-bar change welcome?** It touches shipped structure (`RootView`), so it is a
   recommendation rather than an edit.
3. **Inbound tracking** — the "orders coming to me" idea. It cannot be live, only
   record-keeping. Worth a round, or park it?
4. **iPad.** Worth designing the regular-width layout in this session, or is iPhone the whole
   product for now?
